<div align="center">
  <img src=".github/assets/badge.png" width="230px" />
</div>
<br/>
<div align="center">
  <img src="https://img.shields.io/github/languages/count/vcwild/tcc-proxy?color=%23ff3cbe&style=flat-square" alt="languages" />
  <img src="https://img.shields.io/github/license/vcwild/tcc-proxy?color=%23ff3cbe&style=flat-square" alt="license" />
  <img src="https://img.shields.io/github/repo-size/vcwild/tcc-proxy?color=%23ff3cbe&style=flat-square" alt="repo size" />
  <img src="https://img.shields.io/github/actions/workflow/status/vcwild/tcc-proxy/build.yml?branch=main&style=flat-square&color=%23ff3cbe" alt="build" />
</div>

# tcc-proxy

This Proxy Go's final project. It is an interactive e-book history.

## References

- [Mental canvas](https://www.mentalcanvas.com/)

## License

This project is licensed with an All Rights Reserved license - see the [LICENSE](LICENSE) file for details.
